import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, BarChart, Bar, PieChart, Pie, Cell, ScatterChart, Scatter, ResponsiveContainer } from 'recharts';
import { Calendar, CloudRain, Car, AlertTriangle, TrendingUp, MapPin, Clock, Users } from 'lucide-react';

const TrafficAccidentDashboard = () => {
  // Simulated real-time Indian traffic accident data
  const [currentData, setCurrentData] = useState({
    totalAccidents: 47832,
    fatalities: 15421,
    injuries: 32411,
    riskLevel: 'High',
    lastUpdated: new Date().toLocaleString()
  });

  const [selectedState, setSelectedState] = useState('All States');
  const [selectedTimeRange, setSelectedTimeRange] = useState('Last 30 Days');
  const [weatherFilter, setWeatherFilter] = useState('All');

  // Indian states accident data
  const stateData = [
    { state: 'Maharashtra', accidents: 8234, fatalities: 2341, population: 112374333, riskScore: 85 },
    { state: 'Tamil Nadu', accidents: 6542, fatalities: 1876, population: 72147030, riskScore: 78 },
    { state: 'Karnataka', accidents: 5821, fatalities: 1654, population: 61095297, riskScore: 72 },
    { state: 'Uttar Pradesh', accidents: 9876, fatalities: 3124, population: 199812341, riskScore: 68 },
    { state: 'Gujarat', accidents: 4532, fatalities: 1234, population: 60439692, riskScore: 65 },
    { state: 'Rajasthan', accidents: 3876, fatalities: 1098, population: 68548437, riskScore: 62 },
    { state: 'West Bengal', accidents: 4123, fatalities: 1456, population: 91276115, riskScore: 58 },
    { state: 'Andhra Pradesh', accidents: 3654, fatalities: 987, population: 49577103, riskScore: 55 }
  ];

  // Weather correlation data
  const weatherData = [
    { condition: 'Clear', accidents: 12456, percentage: 26 },
    { condition: 'Rain', accidents: 18234, percentage: 38 },
    { condition: 'Fog', accidents: 8765, percentage: 18 },
    { condition: 'Cloudy', accidents: 6543, percentage: 14 },
    { condition: 'Extreme Weather', accidents: 1834, percentage: 4 }
  ];

  // Time-based accident trends
  const timeData = [
    { hour: '00:00', accidents: 234 }, { hour: '01:00', accidents: 178 }, { hour: '02:00', accidents: 145 },
    { hour: '03:00', accidents: 123 }, { hour: '04:00', accidents: 167 }, { hour: '05:00', accidents: 298 },
    { hour: '06:00', accidents: 456 }, { hour: '07:00', accidents: 678 }, { hour: '08:00', accidents: 834 },
    { hour: '09:00', accidents: 567 }, { hour: '10:00', accidents: 445 }, { hour: '11:00', accidents: 523 },
    { hour: '12:00', accidents: 612 }, { hour: '13:00', accidents: 578 }, { hour: '14:00', accidents: 634 },
    { hour: '15:00', accidents: 723 }, { hour: '16:00', accidents: 812 }, { hour: '17:00', accidents: 934 },
    { hour: '18:00', accidents: 1123 }, { hour: '19:00', accidents: 987 }, { hour: '20:00', accidents: 765 },
    { hour: '21:00', accidents: 654 }, { hour: '22:00', accidents: 543 }, { hour: '23:00', accidents: 432 }
  ];

  // Road type analysis
  const roadTypeData = [
    { type: 'National Highways', accidents: 15234, fatalities: 4567, severity: 'High' },
    { type: 'State Highways', accidents: 12876, fatalities: 3456, severity: 'Medium-High' },
    { type: 'Urban Roads', accidents: 18945, fatalities: 5432, severity: 'High' },
    { type: 'Rural Roads', accidents: 9876, fatalities: 2876, severity: 'Medium' }
  ];

  // ML Prediction factors
  const predictionFactors = [
    { factor: 'Weather Conditions', weight: 0.25, impact: 'High' },
    { factor: 'Traffic Volume', weight: 0.22, impact: 'High' },
    { factor: 'Road Type', weight: 0.18, impact: 'Medium-High' },
    { factor: 'Time of Day', weight: 0.15, impact: 'Medium' },
    { factor: 'Day of Week', weight: 0.12, impact: 'Medium' },
    { factor: 'Vehicle Type', weight: 0.08, impact: 'Low-Medium' }
  ];

  // KPI Cards Component
  const KPICard = ({ title, value, icon: Icon, trend, color }) => (
    <div className={`bg-white rounded-lg shadow-md p-6 border-l-4 ${color}`}>
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900">{value}</p>
          {trend && <p className={`text-sm ${trend > 0 ? 'text-red-600' : 'text-green-600'}`}>
            {trend > 0 ? '↑' : '↓'} {Math.abs(trend)}%
          </p>}
        </div>
        <Icon className="h-8 w-8 text-gray-400" />
      </div>
    </div>
  );

  // Colors for charts
  const COLORS = ['#0088FE', '#00C49F', '#FFBB28', '#FF8042', '#8884D8'];

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentData(prev => ({
        ...prev,
        totalAccidents: prev.totalAccidents + Math.floor(Math.random() * 5),
        lastUpdated: new Date().toLocaleString()
      }));
    }, 10000);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900 mb-2">
          Indian Road Traffic Accident Prediction System
        </h1>
        <p className="text-gray-600">ML-based Real-time Analysis & Forecasting Dashboard</p>
        <div className="flex items-center mt-2 text-sm text-gray-500">
          <Clock className="h-4 w-4 mr-1" />
          Last Updated: {currentData.lastUpdated}
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-lg shadow-md p-4 mb-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">State</label>
            <select 
              value={selectedState} 
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            >
              <option>All States</option>
              {stateData.map(state => (
                <option key={state.state}>{state.state}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Time Range</label>
            <select 
              value={selectedTimeRange} 
              onChange={(e) => setSelectedTimeRange(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            >
              <option>Last 30 Days</option>
              <option>Last 90 Days</option>
              <option>Last 6 Months</option>
              <option>Last Year</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Weather</label>
            <select 
              value={weatherFilter} 
              onChange={(e) => setWeatherFilter(e.target.value)}
              className="w-full border border-gray-300 rounded-md px-3 py-2"
            >
              <option>All</option>
              <option>Clear</option>
              <option>Rain</option>
              <option>Fog</option>
              <option>Cloudy</option>
            </select>
          </div>
          <div className="flex items-end">
            <button className="w-full bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700">
              Generate Prediction
            </button>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <KPICard 
          title="Total Accidents" 
          value={currentData.totalAccidents.toLocaleString()} 
          icon={Car} 
          trend={2.3} 
          color="border-red-500" 
        />
        <KPICard 
          title="Fatalities" 
          value={currentData.fatalities.toLocaleString()} 
          icon={AlertTriangle} 
          trend={-1.2} 
          color="border-orange-500" 
        />
        <KPICard 
          title="Injuries" 
          value={currentData.injuries.toLocaleString()} 
          icon={Users} 
          trend={1.8} 
          color="border-yellow-500" 
        />
        <KPICard 
          title="Risk Level" 
          value={currentData.riskLevel} 
          icon={TrendingUp} 
          color="border-green-500" 
        />
      </div>

      {/* Main Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        
        {/* Hourly Accident Trend */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Accident Trends by Hour</h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={timeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="accidents" stroke="#8884d8" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        {/* Weather Impact */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Weather Impact on Accidents</h3>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={weatherData}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({name, percentage}) => `${name}: ${percentage}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="accidents"
              >
                {weatherData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip />
            </PieChart>
          </ResponsiveContainer>
        </div>

        {/* State-wise Analysis */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">State-wise Accident Analysis</h3>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={stateData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="state" angle={-45} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="accidents" fill="#8884d8" />
              <Bar dataKey="fatalities" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Risk Score vs Population */}
        <div className="bg-white rounded-lg shadow-md p-6">
          <h3 className="text-lg font-semibold mb-4">Risk Score vs Population Density</h3>
          <ResponsiveContainer width="100%" height={300}>
            <ScatterChart data={stateData}>
              <CartesianGrid />
              <XAxis dataKey="population" name="Population" />
              <YAxis dataKey="riskScore" name="Risk Score" />
              <Tooltip cursor={{ strokeDasharray: '3 3' }} />
              <Scatter dataKey="riskScore" fill="#8884d8" />
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Road Type Analysis */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h3 className="text-lg font-semibold mb-4">Road Type Impact Analysis</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={roadTypeData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="type" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="accidents" fill="#8884d8" />
              <Bar dataKey="fatalities" fill="#82ca9d" />
            </BarChart>
          </ResponsiveContainer>
          
          <div className="space-y-4">
            <h4 className="font-semibold">Road Safety Insights</h4>
            {roadTypeData.map((road, index) => (
              <div key={index} className="border-l-4 border-blue-500 pl-4">
                <h5 className="font-medium">{road.type}</h5>
                <p className="text-sm text-gray-600">
                  {road.accidents.toLocaleString()} accidents, {road.fatalities.toLocaleString()} fatalities
                </p>
                <span className={`text-xs px-2 py-1 rounded ${
                  road.severity === 'High' ? 'bg-red-100 text-red-800' :
                  road.severity === 'Medium-High' ? 'bg-orange-100 text-orange-800' :
                  'bg-yellow-100 text-yellow-800'
                }`}>
                  {road.severity} Severity
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* ML Prediction Factors */}
      <div className="bg-white rounded-lg shadow-md p-6 mb-8">
        <h3 className="text-lg font-semibold mb-4">ML Model Prediction Factors</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium mb-3">Factor Importance Weights</h4>
            <div className="space-y-3">
              {predictionFactors.map((factor, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <div className="w-32 text-sm">{factor.factor}</div>
                  <div className="flex-1 bg-gray-200 rounded-full h-2">
                    <div 
                      className="bg-blue-600 h-2 rounded-full" 
                      style={{ width: `${factor.weight * 100}%` }}
                    ></div>
                  </div>
                  <div className="text-sm text-gray-600">{(factor.weight * 100).toFixed(0)}%</div>
                </div>
              ))}
            </div>
          </div>
          
          <div>
            <h4 className="font-medium mb-3">Model Performance Metrics</h4>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span>Accuracy:</span>
                <span className="font-semibold text-green-600">87.3%</span>
              </div>
              <div className="flex justify-between">
                <span>Precision:</span>
                <span className="font-semibold text-blue-600">84.7%</span>
              </div>
              <div className="flex justify-between">
                <span>Recall:</span>
                <span className="font-semibold text-orange-600">89.2%</span>
              </div>
              <div className="flex justify-between">
                <span>F1-Score:</span>
                <span className="font-semibold text-purple-600">86.9%</span>
              </div>
            </div>
            
            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <h5 className="font-medium text-blue-800">Current Prediction</h5>
              <p className="text-sm text-blue-700 mt-1">
                High risk period: 6-9 PM today. Expected 15% increase in accidents due to rainy conditions.
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Footer */}
      <div className="bg-white rounded-lg shadow-md p-4 text-center">
        <p className="text-sm text-gray-600">
          Data Sources: Ministry of Road Transport & Highways (MoRTH), Indian Meteorological Department (IMD), 
          iRAD Database | Model: Random Forest + LSTM Hybrid
        </p>
      </div>
    </div>
  );
};

export default TrafficAccidentDashboard;
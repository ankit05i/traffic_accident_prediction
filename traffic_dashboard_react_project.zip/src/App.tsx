import React from 'react';
import TrafficAccidentDashboard from './TrafficAccidentDashboard';

function App() {
  return <TrafficAccidentDashboard />;
}

export default App;
